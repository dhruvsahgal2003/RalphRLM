# Agent Guide

This document is designed to assist AI coding agents in navigating and understanding the codebase effectively.

## System Summary

**RalphRLM** is a Visual Studio Code extension designed to implement the "Ralph Loop" methodology within the Antigravity ecosystem. By leveraging the internal gRPC-Web API of Antigravity (Codeium's AI), it facilitates autonomous, iterative coding sessions where each iteration operates with a fresh context.

The repository is hosted at: `https://github.com/dhruvsahgal2003/RalphRLM`

## Developer Handbook

Essential commands for building and maintaining the extension:

| Command | Description |
| :--- | :--- |
| `make install` | Install all dependencies |
| `make compile` | Compile TypeScript source to `out/` |
| `make lint` | Execute ESLint checks |
| `make format` | Apply Prettier formatting |
| `make build` | Compile and package into a VSIX file |
| `make package` | Create VSIX package (skips user prompts) |
| `make clean` | Cleanup build artifacts (`out/` directory and `.vsix` files) |
| `npm run watch` | Start compilation in watch mode for development |
| `npm run test` | Execute the test suite |

To run a single test file:
`node ./out/test/runTest.js` (ensure compilation is complete first)

## Core Architecture

### Execution Flow
1.  **Initialization**: `extension.ts` bootstraps the extension, registering necessary commands and global state.
2.  **Configuration**: `commands/loop.ts` processes user inputs to generate a `LoopConfig` object.
3.  **Iteration Controller**: `loop/iteration.ts` manages the primary execution loop, handling pause/resume states.
4.  **Agent Orchestration**: `loop/agentRunner.ts` instantiates a new agent context for every iteration and dispatches instructions to Antigravity.

### Key Components

*   **`state.ts` (State Management)**: A singleton storage for global application state, including active loop status, iteration counters, and client connections. All updates are strictly controlled via setter methods.
*   **`antigravityClient/` (API Client)**: Handles communication with Antigravity via gRPC-Web over HTTP/2.
    *   `discovery.ts`: Locates Antigravity's local port and extracts authentication tokens (CSRF & OAuth).
    *   `client.ts`: Manages cascade sessions (creation, messaging, streaming, termination).
    *   `protobuf.ts`: Utilities for Protobuf message framing and payload construction.
*   **`ralphLoopProvider.ts` (UI Provider)**: Manages the VS Code sidebar view, displaying current session metrics and configuration interfaces.

### Data Lifecycle
The typical lifecycle of a loop session:
> User initiates loop -> `LoopConfig` generated -> `iteration.ts` begins cycle -> `agentRunner` creates isolated context -> `antigravityClient` establishes cascade -> Task instructions dispatched -> Response streamed -> Session functionality verifies completion -> Cascade terminated -> Next iteration begins.

### Persistent Mode ("Pseudo Ralph")
An optional mode where a single cascade session is maintained across multiple iterations, rather than being destroyed and recreated. This is managed via `state.pseudoRalphMode`.

## Conventions

*   **Task Specification** (Default: `PRD.md`): A read-only file containing the project requirements and task list.
*   **Progress Log** (Default: `progress.txt`): An append-only log file where the agent records completed work.
*   **Prompt Injection** (Optional): A file containing custom system instructions to be prepended to the agent's context.

## Extension Points

*   **Commands**: Defined in `package.json` and registered in `extension.ts`. Implementations reside in `commands/`.
*   **Configuration**: Schema defined in `package.json` under `contributes.configuration`.
*   **Model Definitions**: Supported AI models are mapped in `antigravityClient/protobuf.ts`. New models should be added to the `MODEL_IDS` constant.
